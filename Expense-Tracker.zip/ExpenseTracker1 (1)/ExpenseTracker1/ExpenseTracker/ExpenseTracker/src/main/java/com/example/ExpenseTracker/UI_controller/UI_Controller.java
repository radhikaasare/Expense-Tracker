package com.example.ExpenseTracker.UI_controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UI_Controller {
	@GetMapping("/home")
	public String getNewFil() {
		return "home";
	}
}
