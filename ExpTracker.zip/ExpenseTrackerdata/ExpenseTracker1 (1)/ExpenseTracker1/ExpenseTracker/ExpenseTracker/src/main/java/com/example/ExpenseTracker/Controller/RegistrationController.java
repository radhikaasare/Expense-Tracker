package com.example.ExpenseTracker.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.ExpenseTracker.Model.User;
import com.example.ExpenseTracker.Service.UserService;

@Controller
public class RegistrationController {

    private final UserService userService;

    @Autowired
    public RegistrationController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, RedirectAttributes redirectAttributes) {
        try {
            // Save the user to the database
            userService.save(user);

            // Add success message to the RedirectAttributes to persist across redirects
            redirectAttributes.addFlashAttribute("message", "Registration successful. Please log in.");

            // Redirect to the login section in main.html
            return "redirect:/main#login";
        } catch (Exception e) {
            // In case of error, add an error message
            redirectAttributes.addFlashAttribute("error", "Registration failed. Please try again.");
            return "redirect:/register";
        }
    }
}
