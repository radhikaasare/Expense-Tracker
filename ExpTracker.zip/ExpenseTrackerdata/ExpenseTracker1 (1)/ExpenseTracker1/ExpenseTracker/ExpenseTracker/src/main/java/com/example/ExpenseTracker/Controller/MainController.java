package com.example.ExpenseTracker.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/main")
    public String showMainPage(Model model) {
        // You can add attributes to the model if needed for Thymeleaf
        return "main"; // Load main.html for registration and login
    }
}
