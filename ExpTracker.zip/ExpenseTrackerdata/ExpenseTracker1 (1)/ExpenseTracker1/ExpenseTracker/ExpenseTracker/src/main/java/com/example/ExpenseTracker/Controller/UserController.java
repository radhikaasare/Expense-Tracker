package com.example.ExpenseTracker.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.ExpenseTracker.Model.User;
import com.example.ExpenseTracker.Service.UserService;

@RestController
@RequestMapping("/api/users")  // REST endpoint for user-related operations
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        try {
            // Save the user to the database
            userService.save(user);
            return ResponseEntity.ok(user);  // Return the created user
        } catch (Exception e) {
            return ResponseEntity.status(500).build();  // Return server error if something goes wrong
        }
    }
}
