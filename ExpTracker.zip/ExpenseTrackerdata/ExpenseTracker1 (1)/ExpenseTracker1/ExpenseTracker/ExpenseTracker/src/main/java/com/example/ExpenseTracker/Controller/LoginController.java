package com.example.ExpenseTracker.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.ExpenseTracker.Model.User;
import com.example.ExpenseTracker.Service.UserService;

@RestController
@RequestMapping("/api")
public class LoginController {

    private final UserService userService;

    @Autowired
    public LoginController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<User> loginUser(@RequestBody User loginDetails) {
        // Find the user by username and password
        User user = userService.findByUsernameAndPassword(loginDetails.getUsername(), loginDetails.getPassword());

        if (user != null) {
            return ResponseEntity.ok(user);  // Return user details if login is successful
        } else {
            return ResponseEntity.status(401).build();  // Unauthorized if username or password is invalid
        }
    }
}
